# MongoDB Code of Conduct

The Code of Conduct outlines the expectations for our behavior as members of the MongoDB community.
We value the participation of each member of the MongoDB community and want all participants to have an enjoyable and fulfilling experience.

Thanks for reading the [MongoDB Code of Conduct](https://www.mongodb.com/community-code-of-conduct).
